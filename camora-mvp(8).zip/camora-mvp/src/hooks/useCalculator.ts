"use client";

import { useState, useCallback, useMemo, useEffect } from "react";
import { calculate } from "@/lib/engine";
import type { SystemResult, CameraConfig } from "@/lib/engine";
import type { CameraRow, CalculatorFormState } from "@/types/calculator";
import { DEFAULT_CAMERA_CONFIG } from "@/lib/constants";
import { decodeParamsToState, encodeStateToParams } from "@/lib/shareUrl";

export function generateRowId(): string {
  return `row-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
}

function makeDefaultRow(): CameraRow {
  return {
    ...DEFAULT_CAMERA_CONFIG,
    id:     generateRowId(),
    _rowId: generateRowId(),
  };
}

interface UseCalculatorReturn {
  state:                 CalculatorFormState;
  result:                SystemResult | null;
  error:                 string | null;
  addRow:                () => void;
  removeRow:             (rowId: string) => void;
  updateRow:             (rowId: string, patch: Partial<CameraConfig>) => void;
  duplicateRow:          (rowId: string) => void;
  setConservativeMode:   (v: boolean) => void;
  setOverheadMultiplier: (v: number) => void;
  setRaidOverride:       (v: CalculatorFormState['raidOverride']) => void;
}

export function useCalculator(): UseCalculatorReturn {
  // Initialise state from URL params if present, else defaults
  const [state, setState] = useState<CalculatorFormState>(() => {
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      const fromUrl = decodeParamsToState(params, makeDefaultRow);
      if (fromUrl) return fromUrl;
    }
    return {
      rows:                     [makeDefaultRow()],
      conservativeMode:          false,
      storageOverheadMultiplier: 1.20,
      raidOverride:              'auto',
    };
  });

  // Sync state → URL whenever state changes (replaceState, no history push)
  useEffect(() => {
    if (typeof window === 'undefined') return;
    const params = encodeStateToParams(state);
    const newUrl = `${window.location.pathname}?${params.toString()}`;
    window.history.replaceState(null, '', newUrl);
  }, [state]);

  const { result, error } = useMemo(() => {
    try {
      const r = calculate(state.rows, {
        conservativeMode:          state.conservativeMode,
        storageOverheadMultiplier: state.storageOverheadMultiplier,
        raidOverride:              state.raidOverride !== 'auto' ? state.raidOverride : undefined,
      });
      return { result: r, error: null };
    } catch (e) {
      return { result: null, error: e instanceof Error ? e.message : String(e) };
    }
  }, [state]);

  const addRow = useCallback(() => {
    setState((prev) => ({ ...prev, rows: [...prev.rows, makeDefaultRow()] }));
  }, []);

  const removeRow = useCallback((rowId: string) => {
    setState((prev) => ({ ...prev, rows: prev.rows.filter((r) => r._rowId !== rowId) }));
  }, []);

  const updateRow = useCallback((rowId: string, patch: Partial<CameraConfig>) => {
    setState((prev) => ({
      ...prev,
      rows: prev.rows.map((row) => row._rowId === rowId ? { ...row, ...patch } : row),
    }));
  }, []);

  const duplicateRow = useCallback((rowId: string) => {
    setState((prev) => {
      const source = prev.rows.find((r) => r._rowId === rowId);
      if (!source) return prev;
      const newRow: CameraRow = { ...source, id: generateRowId(), _rowId: generateRowId() };
      const idx  = prev.rows.findIndex((r) => r._rowId === rowId);
      const rows = [...prev.rows];
      rows.splice(idx + 1, 0, newRow);
      return { ...prev, rows };
    });
  }, []);

  const setConservativeMode = useCallback((v: boolean) => {
    setState((prev) => ({ ...prev, conservativeMode: v }));
  }, []);

  const setOverheadMultiplier = useCallback((v: number) => {
    setState((prev) => ({ ...prev, storageOverheadMultiplier: v }));
  }, []);

  const setRaidOverride = useCallback((v: CalculatorFormState['raidOverride']) => {
    setState((prev) => ({ ...prev, raidOverride: v }));
  }, []);

  return { state, result, error, addRow, removeRow, updateRow, duplicateRow, setConservativeMode, setOverheadMultiplier, setRaidOverride };
}
